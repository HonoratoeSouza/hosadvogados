Instruções para publicar no GitHub Pages:

1) Crie um repositório público no GitHub (https://github.com/new) com o nome 'hosadvogados'.
2) No repositório, clique em 'Add file' -> 'Upload files' e arraste este arquivo index.html.
3) Clique em 'Commit changes'.
4) Vá em Settings -> Pages, selecione 'Deploy from a branch' -> 'main' -> '/ (root)' e salve.
5) Aguarde alguns minutos e acesse: https://honoratoesouza.github.io/hosadvogados/

Se aparecer 404: verifique se o arquivo está nomeado 'index.html' na branch main e na raiz do repositório.